# a6 - Git Basics
git init
git status

git add <file>
git add .

git commit -m "Your commit message"

git log

git remote add origin
https://github.com/Khurana07/a1.git

git push -u origin main

git pull origin main

git clone https://github.com/Khurana07/a1.git

git clean -f
