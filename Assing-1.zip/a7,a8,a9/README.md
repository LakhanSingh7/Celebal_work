# a7 - Git Basics
git init

git remote add origin 
https://github.com/Khurana07/a7.git

touch example.txt
git add example.txt

git commit -m "Add example.txt"

git push -u origin master
