#!/bin/bash
touch sample.txt

chmod 754 sample.txt
